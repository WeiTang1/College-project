/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pathx.ui;

/**
 *
 * @author Wei
 */
public enum pathXSpriteState
{
    INVISIBLE_STATE,
    VISIBLE_STATE,
    SELECTED_STATE,
    MOUSE_OVER_STATE
}