/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pathx.data;

/**
 *
 * @author WTang
 */
public enum EditMode
{
    NOTHING_SELECTED,
    INTERSECTION_SELECTED,
    INTERSECTION_DRAGGED,
    ROAD_SELECTED,
    ADDING_INTERSECTION,
    ADDING_ROAD_START,
    ADDING_ROAD_END
}
